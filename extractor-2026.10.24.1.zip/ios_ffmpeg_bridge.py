"""FFmpeg 类命令的宿主 runner 桥接合同。

本模块只维护 Python 侧 callable 注入点；当前代码不能据此宣称 Swift 已注册或
启用了 FFmpeg bridge，也不应把 FFmpegKit 视为已确认实现。若宿主选择实现该
合同，``ios_subprocess_hook`` 可将识别出的 FFmpeg/FFprobe 类 argv 同步转发。
runner 为进程级无锁状态，调用线程、超时和取消均由宿主自行处理。
"""

from __future__ import annotations

import errno

from ios_debug_log import log, log_preview

# 进程级可选 runner；仅 _RUNNER 非空不代表其后端当前可用。
_RUNNER = None


def register_runner(runner) -> None:
    """注册 FFmpeg 命令 runner。

    Args:
        runner: callable，合同为
            ``runner(argv: list[str], stdin_text: str) -> (stdout, stderr, returncode)``。

    Returns:
        ``None``。

    Raises:
        TypeError: runner 为空或不可调用。

    Side Effects:
        无锁替换进程级 ``_RUNNER`` 并写日志；不安装 subprocess hook。
    """
    global _RUNNER
    if runner is None or not callable(runner):
        raise TypeError('runner must be callable')
    _RUNNER = runner
    log('ffmpeg_bridge', 'Swift FFmpeg runner registered')


def unregister_runner() -> None:
    """清除 FFmpeg runner 引用。

    Returns:
        ``None``。

    Side Effects:
        无锁清空 ``_RUNNER`` 并写日志；不会撤销 subprocess monkey patch，也
        不会终止已进入 runner 的工作。
    """
    global _RUNNER
    _RUNNER = None
    log('ffmpeg_bridge', 'Swift FFmpeg runner unregistered')


def is_bridge_available() -> bool:
    """返回当前时刻是否已注入 runner。

    Returns:
        runner 引用非空时为 ``True``。

    Side Effects:
        无；这是无锁瞬时检查，不验证后端能力。
    """
    return _RUNNER is not None


def execute_via_bridge(argv, stdin_data=None) -> tuple[str, str, int]:
    """同步调用宿主 runner 并规范化 subprocess 风格结果。

    Args:
        argv: 命令参数序列，各项会转为字符串。
        stdin_data: 可选 bytes/字符串；bytes 以 UTF-8 replacement 模式解码。

    Returns:
        ``(stdout: str, stderr: str, returncode: int)``。

    Raises:
        OSError: runner 未注册。
        RuntimeError: runner 返回值不是至少三项的 list/tuple。
        ValueError/TypeError: returncode 无法转为整数或参数不符合宿主合同。
        Exception: runner 自身异常原样传播。

    Side Effects:
        在当前线程同步执行宿主代码并写共享日志；无内建超时/取消。argv 预览只
        截断、不脱敏，调用方不得传入适合泄露的敏感参数。
    """
    if _RUNNER is None:
        raise OSError(
            errno.ENOENT,
            'Swift FFmpeg runner not registered. '
            'Embedding FFmpegKit in the host is not enough; ios_ffmpeg_bridge.register_runner '
            'must be called. Current app does not register it, so download_media uses the '
            'no-ffmpeg format chain.',
        )

    argv_list = [str(part) for part in argv]
    stdin_text = ''
    if stdin_data is not None:
        stdin_text = (
            stdin_data.decode('utf-8', errors='replace')
            if isinstance(stdin_data, bytes)
            else str(stdin_data)
        )

    log('ffmpeg_bridge', f'execute argv0={argv_list[0] if argv_list else "?"} argc={len(argv_list)}')
    if len(argv_list) > 1:
        log_preview('ffmpeg_bridge', 'argv tail', ' '.join(argv_list[1:]), limit=320)

    result = _RUNNER(argv_list, stdin_text)
    if not isinstance(result, (list, tuple)) or len(result) < 3:
        raise RuntimeError('FFmpeg runner must return (stdout, stderr, returncode)')

    stdout = str(result[0] or '')
    stderr = str(result[1] or '')
    returncode = int(result[2])
    log(
        'ffmpeg_bridge',
        f'done returncode={returncode} stdout_len={len(stdout)} stderr_len={len(stderr)}',
    )
    return stdout, stderr, returncode
