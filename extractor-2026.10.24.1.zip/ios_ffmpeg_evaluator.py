"""FFmpeg 类外部命令的纯字符串识别辅助。

本模块不执行命令，也不表示 Swift 侧已注册 FFmpeg runner；它只供
``ios_subprocess_hook`` 判断某个 argv[0] 是否应尝试转发给
``ios_ffmpeg_bridge``。匹配范围刻意包含传统别名，以及以 ffmpeg/ffprobe
开头的定制可执行文件名。
"""

from __future__ import annotations

import os


# 识别集合是进程内只读常量；除精确名称外，is_ffmpeg_program 还接受前缀匹配。
_FFMPEG_NAMES = frozenset({
    'ffmpeg',
    'ffprobe',
    'avconv',
    'avprobe',
})


def normalize_program_name(name: str) -> str:
    """规范化待识别的可执行文件名。

    Args:
        name: argv 中的程序名或路径；空值会按空字符串处理。

    Returns:
        去除目录、转为小写并移除可选 ``.exe`` 后缀的名称。

    Raises:
        不主动抛出异常；``str``/路径处理自身的异常会原样传播。

    Side Effects:
        无。该函数不访问文件系统，也不修改全局状态。
    """
    base = os.path.basename(str(name or '')).lower()
    if base.endswith('.exe'):
        base = base[:-4]
    return base


def is_ffmpeg_program(program: str) -> bool:
    """判断命令是否应进入 FFmpeg bridge 路由。

    Args:
        program: 待判断的程序名或路径。

    Returns:
        精确匹配 FFmpeg/FFprobe 及其传统别名时为 ``True``；规范化名称以
        ``ffmpeg`` 或 ``ffprobe`` 开头时也为 ``True``。

    Side Effects:
        无。返回 ``True`` 仅代表路由候选，不保证 bridge 已注册或命令可执行。
    """
    base = normalize_program_name(program)
    if base in _FFMPEG_NAMES:
        return True
    return base.startswith('ffmpeg') or base.startswith('ffprobe')
