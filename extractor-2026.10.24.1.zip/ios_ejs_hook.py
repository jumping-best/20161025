"""把 yt-dlp YouTube EJS challenge 执行路径适配到 iOS JS bridge。

安装时会替换 EJS builtin source 与 Node/Deno/QuickJS/Bun provider 的执行方法，
并明确让 Deno/Bun provider 报不可用；QuickJS provider 并未被禁用。builtin lib/core
优先读取本包 ``ejs`` 资源，缺失时回退安装前保存的上游实现。

这些是进程级 monkey patch，没有 unapply：删除 ``sys.modules`` 项、注销 runner
或重新导入本模块都不等于撤销已经写入类对象的方法。安装无锁，首次并发调用可能
竞态。本模块只描述 JS runner 合同；当前 Swift 可确认注册 JS runner。
"""

from __future__ import annotations

import os
import sys

from ios_debug_log import log, log_preview, log_timing
from ios_js_evaluator import clean_js_runtime_stderr

# 安装标记与上游方法引用是进程级状态；资源版本/文件名是只读包合同。
_EJS_HOOK_INSTALLED = False
_EJS_VERSION = '0.8.0'
_EJS_LIB_FILE = 'yt.solver.lib.min.js'
_EJS_CORE_FILE = 'yt.solver.core.min.js'
_ORIGINAL_BUILTIN_SOURCE = None


def _bundled_ejs_dir() -> str:
    """计算第一方 EJS 资源目录。

    Returns:
        相对本模块位置构造的目录路径。

    Side Effects:
        无；不检查目录是否存在。
    """
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ejs')


def _load_bundled_ejs_file(filename: str) -> str | None:
    """读取指定 bundled EJS 文本。

    Args:
        filename: 资源目录下的文件名。

    Returns:
        UTF-8 文件全文；文件不存在时返回 ``None``。

    Raises:
        OSError/UnicodeError: 文件存在但无法读取或解码。

    Side Effects:
        读取文件系统，不修改资源。
    """
    path = os.path.join(_bundled_ejs_dir(), filename)
    if not os.path.isfile(path):
        return None
    with open(path, encoding='utf-8') as handle:
        return handle.read()


def _ios_builtin_source(self, script_type):
    """为 yt-dlp EJS provider 提供 bundled 或上游 builtin Script。

    Args:
        self: 被 monkey patch 的 ``EJSBaseJCP`` 实例。
        script_type: yt-dlp 的脚本类型枚举。

    Returns:
        LIB/CORE 对应的 bundled ``Script``；资源缺失或未知类型时调用保存的上游
        方法。没有可回退方法时返回 ``None``。

    Raises:
        文件读取、yt-dlp 类型构造或上游实现异常原样传播。

    Side Effects:
        可能读取 EJS 文件并写诊断日志；不修改脚本内容。
    """
    from yt_dlp.extractor.youtube.jsc._builtin.ejs import (
        Script,
        ScriptSource,
        ScriptType,
        ScriptVariant,
    )

    filename = {
        ScriptType.LIB: _EJS_LIB_FILE,
        ScriptType.CORE: _EJS_CORE_FILE,
    }.get(script_type)
    if not filename:
        if _ORIGINAL_BUILTIN_SOURCE is not None:
            return _ORIGINAL_BUILTIN_SOURCE(self, script_type)
        return None

    code = _load_bundled_ejs_file(filename)
    if code:
        log('ejs_hook', f'using bundled EJS {filename} len={len(code)}')
        return Script(
            script_type,
            ScriptVariant.MINIFIED,
            ScriptSource.BUILTIN,
            _EJS_VERSION,
            code,
        )

    log('ejs_hook', f'bundled EJS missing: {filename}, fallback to upstream builtin')
    if _ORIGINAL_BUILTIN_SOURCE is not None:
        return _ORIGINAL_BUILTIN_SOURCE(self, script_type)
    return None


def _ios_run_js_runtime(self, stdin: str) -> str:
    """把 provider 的同步 JavaScript 请求交给宿主 JS runner。

    Args:
        self: Node/Deno/QuickJS/Bun provider 实例。
        stdin: provider 生成的 JavaScript 源码。

    Returns:
        非空 stdout 文本。

    Raises:
        JsChallengeProviderError: bridge 异常、清理后仍有 stderr，或 stdout 为空。

    Side Effects:
        在调用线程同步执行 runner、记录计时及限长预览。预览不脱敏，源码与输出
        在进入本层前必须已避免敏感用户数据。
    """
    from ios_js_bridge import evaluate_via_bridge, is_bridge_available
    from yt_dlp.extractor.youtube.jsc.provider import JsChallengeProviderError

    provider = getattr(self, 'PROVIDER_NAME', type(self).__name__)
    runtime = getattr(self, 'JS_RUNTIME_NAME', '?')
    log(
        'ejs_hook',
        f'_run_js_runtime provider={provider} runtime={runtime} '
        f'bridge_available={is_bridge_available()} stdin_len={len(stdin or "")}',
    )

    try:
        with log_timing('ejs_hook', f'evaluate provider={provider}'):
            stdout, stderr = evaluate_via_bridge(stdin)
    except Exception as exc:  # noqa: BLE001
        log('ejs_hook', f'bridge error provider={provider}: {exc}')
        raise JsChallengeProviderError(f'iOS JS bridge error: {exc}') from exc

    stderr = clean_js_runtime_stderr(stderr)
    if stderr:
        log_preview('ejs_hook', 'stderr', stderr)
        raise JsChallengeProviderError(f'Error running JS runtime: {stderr.strip()}')
    if not stdout:
        log('ejs_hook', f'empty stdout provider={provider}')
        raise JsChallengeProviderError('JS runtime produced no output')

    log_preview('ejs_hook', f'stdout provider={provider}', stdout)
    return stdout


def _ios_run_deno_via_bridge(self, stdin, options):
    """兼容 Deno provider 私有调用签名并转发到统一 runner。

    Args:
        self: Deno provider 实例。
        stdin: JavaScript 源码。
        options: 仅用于日志的 Deno options；执行合同不消费其语义。

    Returns:
        ``_ios_run_js_runtime`` 的 stdout。

    Raises:
        JsChallengeProviderError: 统一 runner 路径失败。

    Side Effects:
        写日志并同步调用宿主 runner。Deno provider 同时会被标记为不可用，因此
        这是兼容防线，不表示真实 Deno runtime 可用。
    """
    log('ejs_hook', f'_run_deno intercepted (deno unsupported on iOS) options={options}')
    return _ios_run_js_runtime(self, stdin)


def _ios_provider_disabled(self, /) -> bool:
    """作为 provider ``is_available`` 的固定否定实现。

    Args:
        self: provider 实例，仅为匹配方法签名。

    Returns:
        始终 ``False``。

    Side Effects:
        无。
    """
    return False


def should_enable_ejs_hook(force: bool | None = None) -> bool:
    """判断是否应安装 EJS monkey patch。

    Args:
        force: 非 ``None`` 时直接作为结果；否则检查 ``sys.platform``。

    Returns:
        强制值，或 Apple 移动/空间平台命中结果。

    Side Effects:
        无；不检查 JS runner 是否已注册。
    """
    if force is not None:
        return force
    return sys.platform in {'ios', 'tvos', 'visionos', 'watchos'}


def apply_ejs_hook(force: bool | None = None) -> bool:
    """幂等安装进程级 EJS provider monkey patch。

    Args:
        force: 控制是否绕过平台判断；``None`` 时仅在支持的平台标识安装。

    Returns:
        已安装或本次安装成功时为 ``True``；平台判断拒绝安装时为 ``False``。

    Raises:
        ImportError/AttributeError: yt-dlp 内部模块或私有类形状不符合预期。

    Side Effects:
        保存一次上游 builtin 方法，随后永久替换 EJS builtin source、四个 provider
        的 JS 执行方法、Deno 私有执行方法及 Deno/Bun 可用性方法，并写全局标记。
        无锁、无恢复函数；清理 ``sys.modules`` 不会撤销已写入既有类对象的补丁。
    """
    global _EJS_HOOK_INSTALLED, _ORIGINAL_BUILTIN_SOURCE

    if _EJS_HOOK_INSTALLED:
        return True
    if not should_enable_ejs_hook(force):
        return False

    from yt_dlp.extractor.youtube.jsc._builtin import bun, deno, ejs, node, quickjs

    if _ORIGINAL_BUILTIN_SOURCE is None:
        _ORIGINAL_BUILTIN_SOURCE = ejs.EJSBaseJCP._builtin_source
    ejs.EJSBaseJCP._builtin_source = _ios_builtin_source

    for provider_cls in (node.NodeJCP, deno.DenoJCP, quickjs.QuickJSJCP, bun.BunJCP):
        provider_cls._run_js_runtime = _ios_run_js_runtime
        log('ejs_hook', f'patched {provider_cls.__name__}._run_js_runtime')

    deno.DenoJCP._run_deno = _ios_run_deno_via_bridge
    deno.DenoJCP.is_available = _ios_provider_disabled
    bun.BunJCP.is_available = _ios_provider_disabled
    log('ejs_hook', 'disabled deno/bun providers on iOS')

    _EJS_HOOK_INSTALLED = True
    log('ejs_hook', f'apply_ejs_hook installed bundled_ejs_dir={_bundled_ejs_dir()}')
    return True


def is_ejs_hook_installed() -> bool:
    """读取本进程安装标记。

    Returns:
        ``apply_ejs_hook`` 已完成时为 ``True``。

    Side Effects:
        无。标记不验证所有目标类仍保持 patched 状态，也不代表 runner 可用。
    """
    return _EJS_HOOK_INSTALLED
