"""JavaScript runtime 命令识别、版本近似与执行回退辅助。

``ios_subprocess_hook`` 使用本模块识别 yt-dlp 的 JS 子进程意图。源码执行优先走
已注册的 ``ios_js_bridge``；当前 Swift 可确认注册 JS runner。仅当 bridge 不可
导入或未注册时，桌面测试环境才尝试 Python ``quickjs``。bridge runner 自身报错
不会自动回退。
"""

from __future__ import annotations

import re
import sys

# 只读识别/伪版本表；版本文本用于能力探测，不代表真实二进制存在。
_JS_RUNTIME_NAMES = frozenset({
    'node', 'nodejs', 'deno', 'bun', 'qjs', 'quickjs', 'quickjs-ng',
})

_FAKE_VERSION_OUTPUT = {
    'node': 'v22.11.0\n',
    'deno': 'deno 2.3.0 (stable, release, aarch64-apple-ios)\n',
    'bun': '1.2.11\n',
    'qjs': 'QuickJS-ng version 0.12.0\n',
    'quickjs': 'QuickJS-ng version 0.12.0\n',
}


def _normalize_program_name(name: str) -> str:
    """规范化已经由上层提取出的 JS runtime 名称。

    Args:
        name: 程序名；本函数不会截取目录部分。

    Returns:
        小写并移除可选 ``.exe`` 后缀的名称。

    Side Effects:
        无。subprocess 层负责先取 basename。
    """
    base = name.lower()
    if base.endswith('.exe'):
        return base[:-4]
    return base


def is_js_runtime_name(name: str) -> bool:
    """判断名称是否属于支持近似的 JS runtime。

    Args:
        name: 已规范为程序名的字符串。

    Returns:
        精确命中已知集合，或以 ``quickjs`` 开头时为 ``True``。

    Side Effects:
        无。
    """
    base = _normalize_program_name(name)
    if base in _JS_RUNTIME_NAMES:
        return True
    return base.startswith('quickjs')


def fake_version_output(program: str) -> str | None:
    """返回能力探测用的伪版本输出。

    Args:
        program: JS runtime 名称。

    Returns:
        对应的 stdout 文本；未知名称返回 ``None``。QuickJS 别名共享同一版本。

    Side Effects:
        无。返回版本不证明任何外部 runtime 已安装。
    """
    base = _normalize_program_name(program)
    if base in ('qjs', 'quickjs', 'quickjs-ng'):
        return _FAKE_VERSION_OUTPUT['qjs']
    return _FAKE_VERSION_OUTPUT.get(base)


def is_version_probe(argv: list[str]) -> bool:
    """识别 yt-dlp 常见的 runtime 版本/帮助探测 argv。

    Args:
        argv: 完整参数列表。

    Returns:
        参数集合含 ``--version`` 时为真；已知 runtime 的 ``--help`` 或精确 ``-h``
        调用也为真。少于两个参数时为假。

    Side Effects:
        无；不执行命令。
    """
    if len(argv) < 2:
        return False
    flags = {arg.lower() for arg in argv[1:]}
    if '--version' in flags:
        return True
    if '--help' in flags and is_js_runtime_name(argv[0]):
        return True
    if argv[1:] == ['-h'] and is_js_runtime_name(argv[0]):
        return True
    return False


def is_js_stdin_execution(argv: list[str]) -> bool:
    """识别以标准输入作为脚本的 JS runtime 调用。

    Args:
        argv: 完整参数列表。

    Returns:
        argv 非空、末项为 ``-`` 且首项是已知 runtime 时为 ``True``。

    Side Effects:
        无。
    """
    return bool(argv) and argv[-1] == '-' and is_js_runtime_name(argv[0])


def is_quickjs_script_execution(argv: list[str]) -> bool:
    """识别本层支持的 QuickJS ``--script`` 文件调用形状。

    Args:
        argv: 完整参数列表。

    Returns:
        至少三项、首项为已知 JS runtime 且第二项是 ``--script`` 时为 ``True``。

    Side Effects:
        无；实际文件读取由 ``evaluate_script_file`` 完成。
    """
    return (
        len(argv) >= 3
        and is_js_runtime_name(argv[0])
        and argv[1] == '--script'
    )


def _eval_with_quickjs(source: str) -> tuple[str, str]:
    """在桌面 Python quickjs 模块中执行源码。

    Args:
        source: JavaScript 源码。

    Returns:
        最后一条 ``console.log`` 文本与空 stderr。

    Raises:
        ImportError: quickjs 模块不可用。
        RuntimeError: 脚本没有产生 console 输出。
        Exception: Context 创建或 JS 求值错误原样传播。

    Side Effects:
        在当前进程创建 QuickJS context 并执行任意脚本；只收集 console.log，
        不提供宿主线程切换或取消。
    """
    import quickjs  # type: ignore[import-untyped]

    output: list[str] = []

    def _log(message: str) -> None:
        """收集当前 QuickJS context 的一条 console 输出。"""
        output.append(message)

    ctx = quickjs.Context()
    ctx.add_callable('__ios_console_log', _log)
    ctx.eval(
        'if (typeof console === "undefined") {'
        '  var console = { log: function(msg) { __ios_console_log(String(msg)); } };'
        '}'
    )
    ctx.eval(source, filename='yt-dlp-jsc.js')
    if not output:
        raise RuntimeError('JS runtime produced no console output')
    return output[-1], ''


def evaluate_javascript(source: str) -> tuple[str, str]:
    """执行 JavaScript，优先宿主 bridge，桌面环境回退 quickjs。

    Args:
        source: 非空源码字符串。

    Returns:
        ``(stdout, stderr)`` 字符串二元组。

    Raises:
        RuntimeError: 源码为空，或既无可用 bridge 也无 quickjs。
        Exception: 已注册 bridge runner 或 quickjs 执行失败时原样传播。

    Side Effects:
        同步执行宿主 runner 或本地 JS context，并写共享调试日志。只有导入 bridge
        失败或 bridge 未注册才尝试 quickjs；runner 执行异常不会触发回退。
    """
    from ios_debug_log import log

    if not source or not source.strip():
        raise RuntimeError('empty JavaScript source')

    try:
        from ios_js_bridge import evaluate_via_bridge, is_bridge_available

        log('js_evaluator', f'evaluate_javascript bridge_available={is_bridge_available()}')
        if is_bridge_available():
            return evaluate_via_bridge(source)
    except ImportError:
        log('js_evaluator', 'ios_js_bridge not importable, trying quickjs fallback')

    try:
        return _eval_with_quickjs(source)
    except ImportError:
        raise RuntimeError(
            'No JS engine available. On iOS, PythonMediaExtractor must register '
            'ios_js_bridge.register_runner during prepare(); on desktop install quickjs for tests.'
        ) from None


def evaluate_script_file(path: str) -> tuple[str, str]:
    """读取 UTF-8 脚本文件并交给 ``evaluate_javascript``。

    Args:
        path: 脚本文件路径。

    Returns:
        JavaScript 执行产生的 ``(stdout, stderr)``。

    Raises:
        OSError/UnicodeError: 文件读取失败。
        Exception: 执行层异常原样传播。

    Side Effects:
        读取文件并同步执行其内容；不删除或修改文件。
    """
    with open(path, encoding='utf-8') as handle:
        source = handle.read()
    return evaluate_javascript(source)


def clean_js_runtime_stderr(stderr: str) -> str:
    """移除若干已知 runtime 包装噪声行。

    Args:
        stderr: runtime 返回的 stderr 文本。

    Returns:
        保留行以换行符重新拼接的文本；空输入返回空字符串。

    Side Effects:
        无。该清理基于正则/精确文本，也会删除所有以 ``var jsc`` 开头的行，
        调用方不应把它视为完整或语义感知的错误解析器。
    """
    if not stderr:
        return ''
    lines = []
    for line in stderr.splitlines():
        if re.match(r'^\[stdin\]:', line):
            continue
        if re.match(r'^var jsc', line):
            continue
        if line == '(Use `node --trace-uncaught ...` to show where the exception was thrown)':
            continue
        if re.match(r'^Node\.js v\d+\.\d+\.\d+$', line):
            continue
        if re.match(r'^Bun v\d+\.\d+\.\d+ \(', line):
            continue
        lines.append(line)
    return '\n'.join(lines)


def is_ios_platform() -> bool:
    """判断 Python 平台标识是否属于 Apple 移动/空间平台集合。

    Returns:
        ``sys.platform`` 命中 iOS、tvOS、visionOS 或 watchOS 时为 ``True``。

    Side Effects:
        无。该判断不验证具体宿主能力或 bridge 注册状态。
    """
    return sys.platform in {'ios', 'tvos', 'visionos', 'watchos'}
