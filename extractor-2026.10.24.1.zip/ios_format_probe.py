"""对提取结果中的媒体 URL 做有限、并发、保守的可达性探测。

普通 progressive / DASH 默认 GET 读取少量字节且不带 Range；**googlevideo** 改为小
Range（与 iOS BackgroundDownloader 1MiB 分片策略对齐），因整文件 GET 常 403。
HLS 最多读取入口 manifest，若为 master 则只跟进第一条 variant，再只抽检 media
playlist 的第一条分片。明确的 401/403/404/410/451、空响应体、progressive 错误页
正文及无效 HLS 文本会被剔除；其它 HTTP、超时、URL 或系统网络异常采用 soft-keep，
避免把模糊网络故障误判成永久失效。

探测会真实联网，但不是完整下载或全分片校验。同 URL 按字符串去重，只使用首次
出现 format 的 headers；线程池 worker 会并发写共享调试日志。
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin
from urllib.request import Request, urlopen

# 这些常量定义有限探测预算；只读且全进程共享。
_BLOCKED_STATUS = frozenset({401, 403, 404, 410, 451})
_DEFAULT_MAX_WORKERS = 8
# googlevideo 高并发小 Range 易被 CDN 群刷成 403，与单链探活结果不一致。
_GOOGLEVIDEO_MAX_WORKERS = 2
_PROBE_TIMEOUT = 12
_PROBE_READ_BYTES = 8192
_SEGMENT_READ_BYTES = 512
# 与 iOS MediaExtractor / BackgroundDownloader 探活对齐（整文件 GET 常 403）。
_GOOGLEVIDEO_PROBE_RANGE = 'bytes=0-1'
_M3U8_PROTOCOLS = frozenset({'m3u8', 'm3u8_native', 'm3u8_frag'})


def _log(message: str) -> None:
    """尽力写入 format_probe 分类日志。

    Args:
        message: 已脱敏的状态摘要。

    Returns:
        ``None``。

    Side Effects:
        动态导入并写进程共享日志；任何异常被吞掉。函数本身不做脱敏。
    """
    try:
        from ios_debug_log import log

        log('format_probe', message)
    except Exception:  # noqa: BLE001
        pass


def is_storyboard_format(fmt):
    """识别不可作为音视频下载项的 storyboard format。

    Args:
        fmt: yt-dlp format 字典。

    Returns:
        protocol 为 MHTML、format note 含 storyboard 或 format ID 以 ``sb`` 开头时
        为 ``True``。

    Side Effects:
        无。
    """
    protocol = (fmt.get('protocol') or '').lower()
    if protocol == 'mhtml':
        return True
    note = (fmt.get('format_note') or '').lower()
    if 'storyboard' in note:
        return True
    format_id = (fmt.get('format_id') or '').lower()
    return format_id.startswith('sb')


def strip_storyboard_formats(formats):
    """从 format 序列移除 storyboard。

    Args:
        formats: format iterable 或空值。

    Returns:
        保留原相对顺序的新列表。

    Side Effects:
        无；输入对象不被修改。
    """
    return [fmt for fmt in (formats or []) if not is_storyboard_format(fmt)]


def _url_preview(url: str, limit: int = 96) -> str:
    """生成 URL 的字符数限制预览。

    Args:
        url: 待预览文本。
        limit: 最大保留字符数。

    Returns:
        原文本或带省略号的前缀。

    Side Effects:
        无。此函数**只截断、不脱敏**，不会移除 query、凭据或标识；调用方不得
        把完整私有 URL 送入日志。
    """
    text = str(url or '')
    return text if len(text) <= limit else text[:limit] + '...'


def _should_skip_probe(fmt):
    """判断 format 是否不进入网络探测。

    Args:
        fmt: yt-dlp format 字典。

    Returns:
        storyboard 或 URL 非 HTTP(S) 时为 ``True``；签名 CDN 不特殊跳过。

    Side Effects:
        无。
    """
    if is_storyboard_format(fmt):
        return True
    url = (fmt.get('url') or '').lower()
    return not url.startswith(('http://', 'https://'))


def _looks_like_m3u8(url: str, protocol: str = '') -> bool:
    """按 protocol 或 URL 形状启发式识别 HLS。

    Args:
        url: 媒体 URL。
        protocol: yt-dlp protocol 字段。

    Returns:
        protocol 命中 HLS 集合或 URL 含已知 manifest 片段时为真。

    Side Effects:
        无；不联网且不保证内容确为有效 HLS。
    """
    proto = (protocol or '').lower()
    if proto in _M3U8_PROTOCOLS:
        return True
    lower = (url or '').lower()
    return '.m3u8' in lower or 'playlist/index.m3u8' in lower or '/manifest.' in lower


def _looks_like_error_document(chunk: bytes) -> bool:
    """判断响应开头是不是 HTML / XML / JSON 错误页。

    Args:
        chunk: 已读取的响应前缀。

    Returns:
        去掉空白后以 ``<``、``{`` 或 ``[`` 开头时为 ``True``。媒体容器不以这些字节开头。

    Side Effects:
        无。
    """
    sample = chunk.lstrip(b' \t\r\n')
    return bool(sample) and sample[:1] in (b'<', b'{', b'[')


def _is_googlevideo(url: str) -> bool:
    """识别 YouTube googlevideo / videoplayback CDN。"""
    lower = (url or '').lower()
    return 'googlevideo.com' in lower or 'videoplayback' in lower


def _format_av_kind(fmt) -> str:
    """粗分 audio / video / combined / other（按 acodec/vcodec）。"""
    acodec = str(fmt.get('acodec') or 'none').lower()
    vcodec = str(fmt.get('vcodec') or 'none').lower()
    has_a = acodec not in ('', 'none')
    has_v = vcodec not in ('', 'none')
    if has_a and has_v:
        return 'combined'
    if has_a:
        return 'audio'
    if has_v:
        return 'video'
    return 'other'


def _is_usable_download_set(formats) -> bool:
    """是否足以支撑常见下载：合流，或音+视频轨，或纯音频。"""
    kinds = {_format_av_kind(fmt) for fmt in (formats or []) if isinstance(fmt, dict)}
    if 'combined' in kinds:
        return True
    if 'audio' in kinds and 'video' in kinds:
        return True
    if 'audio' in kinds:
        return True
    return False


def _probe_http(url, headers, *, range_header=None, read_bytes=0, reject_text_body=False):
    """执行一次有上限的 GET，并区分明确失败与模糊错误。

    Args:
        url: HTTP(S) 目标。
        headers: 请求头 mapping。
        range_header: 可选 Range 值。googlevideo 探测应传小 Range；其它 CDN 默认不传，
            以避免「只拒 Range」的站点误杀。
        read_bytes: 成功响应时最多读取的字节数；零表示不校验 body。
        reject_text_body: 为真时，把 HTML/XML/JSON 错误页当成明确失败。只用于媒体直链，
            不用于 HLS/DASH 清单。

    Returns:
        ``(ok, status_or_reason)``。blocked 状态或要求读取但 body 为空时 ``ok=False``；
        其它 HTTP/网络/解析异常 ``ok=True`` 并携带 soft reason。

    Raises:
        构造 headers/request 时未被 try 覆盖的异常可能传播。

    Side Effects:
        发起真实 GET 并读取有限响应体；不下载完整资源，不写文件。
    """
    merged = {str(k): str(v) for k, v in (headers or {}).items() if v is not None}
    if range_header:
        merged['Range'] = range_header
    if _is_googlevideo(url):
        merged.setdefault('Referer', 'https://www.youtube.com/')
        merged.setdefault('Origin', 'https://www.youtube.com')
    request = Request(url, headers=merged, method='GET')
    try:
        with urlopen(request, timeout=_PROBE_TIMEOUT) as response:
            code = getattr(response, 'status', None) or response.getcode()
            if code in _BLOCKED_STATUS:
                return False, code
            if read_bytes > 0:
                chunk = response.read(read_bytes)
                if not chunk:
                    return False, f'empty_body:{code}'
                if reject_text_body and _looks_like_error_document(chunk):
                    return False, f'error_body:{code}'
            return True, code
    except HTTPError as exc:
        if exc.code in _BLOCKED_STATUS:
            return False, exc.code
        return True, f'http:{exc.code}'
    except (URLError, TimeoutError, OSError, ValueError) as exc:
        return True, f'soft:{type(exc).__name__}'


def _iter_m3u8_uris(manifest_text):
    """迭代 manifest 中非空、非标签的 URI 行。

    Args:
        manifest_text: 已解码的 playlist 文本。

    Yields:
        去除首尾空白的相对或绝对 URI，保持原顺序。

    Side Effects:
        无。
    """
    for line in manifest_text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith('#'):
            continue
        yield stripped


def _first_media_segment_url(manifest_text, base_url):
    """解析 media playlist 的第一条非标签 URI。

    Args:
        manifest_text: media playlist 文本。
        base_url: 相对 URI 的解析基准。

    Returns:
        第一条分片的绝对 URL；不存在时为 ``None``。

    Side Effects:
        无；不验证该 URI 是否确为媒体分片，也不联网。
    """
    for uri in _iter_m3u8_uris(manifest_text):
        if uri.startswith(('http://', 'https://')):
            return uri
        return urljoin(base_url, uri)
    return None


def _first_variant_playlist_url(manifest_text, base_url):
    """从 master playlist 选择第一条 variant URI。

    Args:
        manifest_text: master playlist 文本。
        base_url: 相对 URI 的解析基准。

    Returns:
        第一条 ``#EXT-X-STREAM-INF`` 后首个非标签 URI 的绝对 URL；无则 ``None``。

    Side Effects:
        无。函数不比较码率或遍历其它 variant。
    """
    lines = manifest_text.splitlines()
    for index, line in enumerate(lines):
        if not line.strip().startswith('#EXT-X-STREAM-INF'):
            continue
        for follow in lines[index + 1 :]:
            stripped = follow.strip()
            if not stripped or stripped.startswith('#'):
                continue
            if stripped.startswith(('http://', 'https://')):
                return stripped
            return urljoin(base_url, stripped)
    return None


def _fetch_m3u8_text(url, headers):
    """GET 并有限读取一份 HLS playlist。

    Args:
        url: manifest URL。
        headers: 请求头 mapping。

    Returns:
        成功时 ``(decoded_text, 'ok')``；blocked、其它 HTTP/网络错误或内容为空/不含
        ``#EXTM3U`` 时返回 ``(None, reason)``。上层决定 soft-keep 还是剔除。

    Raises:
        headers/request 构造阶段异常可能传播。

    Side Effects:
        发起一次真实 GET，最多读取 ``_PROBE_READ_BYTES``，不写文件。
    """
    merged = {str(k): str(v) for k, v in (headers or {}).items() if v is not None}
    request = Request(url, headers=merged, method='GET')
    try:
        with urlopen(request, timeout=_PROBE_TIMEOUT) as response:
            code = getattr(response, 'status', None) or response.getcode()
            if code in _BLOCKED_STATUS:
                return None, code
            data = response.read(_PROBE_READ_BYTES)
    except HTTPError as exc:
        if exc.code in _BLOCKED_STATUS:
            return None, exc.code
        return None, f'http:{exc.code}'
    except (URLError, TimeoutError, OSError, ValueError) as exc:
        return None, f'soft:{type(exc).__name__}'

    if not data or b'#EXTM3U' not in data:
        return None, 'invalid_m3u8'
    return data.decode('utf-8', errors='replace'), 'ok'


def _probe_one_segment(segment_url, headers):
    """GET 抽检 media playlist 的一个分片。

    Args:
        segment_url: 第一条分片 URL。
        headers: 请求头 mapping。

    Returns:
        ``_probe_http`` 的 ``(ok, reason)``。

    Side Effects:
        不用 Range 发起真实 GET，最多读取 ``_SEGMENT_READ_BYTES``；明确失败时写日志。
    """
    ok, reason = _probe_http(
        segment_url,
        headers,
        read_bytes=_SEGMENT_READ_BYTES,
    )
    if not ok:
        _log(
            f'hls segment blocked reason={reason} '
            f'seg={_url_preview(segment_url)}'
        )
    return ok, reason


def _probe_m3u8(url, headers):
    """有限探测入口 manifest、首个 variant 与首个分片。

    Args:
        url: HLS 入口 URL。
        headers: 所属 format 的请求头。

    Returns:
        明确 blocked、无效 playlist 或抽检分片空/blocked 时为 ``False``；模糊网络/
        其它 HTTP 错误、master 无 variant、media 无 segment 时 soft-keep 为 ``True``。

    Side Effects:
        最多发起入口、第一条 variant、第一条分片三次 GET，并写诊断日志。不会检查
        其余 variant 或分片，因此成功只表示有限样本可用。
    """
    text, reason = _fetch_m3u8_text(url, headers)
    if text is None:
        if isinstance(reason, int) and reason in _BLOCKED_STATUS:
            _log(f'hls manifest blocked status={reason} url={_url_preview(url)}')
            return False
        if reason == 'invalid_m3u8':
            _log(f'hls manifest invalid url={_url_preview(url)}')
            return False
        # soft / 其它 HTTP：保留，避免瞬时网络错误误删格式。
        _log(f'hls manifest soft-keep reason={reason} url={_url_preview(url)}')
        return True

    media_text = text
    media_base = url

    if '#EXT-X-STREAM-INF' in text:
        variant = _first_variant_playlist_url(text, url)
        if not variant:
            _log(f'hls master has no variant url={_url_preview(url)}')
            return True
        media_text, media_reason = _fetch_m3u8_text(variant, headers)
        if media_text is None:
            if isinstance(media_reason, int) and media_reason in _BLOCKED_STATUS:
                _log(
                    f'hls variant blocked status={media_reason} '
                    f'url={_url_preview(variant)}'
                )
                return False
            if media_reason == 'invalid_m3u8':
                _log(f'hls variant invalid url={_url_preview(variant)}')
                return False
            _log(
                f'hls variant soft-keep reason={media_reason} '
                f'url={_url_preview(variant)}'
            )
            return True
        media_base = variant

    segment_url = _first_media_segment_url(media_text, media_base)
    if not segment_url:
        _log(f'hls media has no segment url={_url_preview(media_base)}')
        return True

    ok, _seg_reason = _probe_one_segment(segment_url, headers)
    return ok


def probe_format(fmt):
    """按 format 协议选择有限 HLS、DASH 或 progressive 探测。

    Args:
        fmt: 含 URL、protocol、headers 与 format ID 的 yt-dlp 字典。

    Returns:
        应保留该 format 时为 ``True``。非 HTTP(S)/storyboard 直接返回真；DASH /
        progressive 读取有限字节；googlevideo 带小 Range，其它默认不带 Range。

    Side Effects:
        可能发起网络 GET 并写日志；不修改 ``fmt``。
    """
    if _should_skip_probe(fmt):
        return True

    url = fmt.get('url') or ''
    protocol = (fmt.get('protocol') or '').lower()
    headers = fmt.get('http_headers') or {}
    format_id = fmt.get('format_id') or '?'

    if _looks_like_m3u8(url, protocol):
        ok = _probe_m3u8(url, headers)
        if not ok:
            _log(
                f'remove format_id={format_id} kind=hls '
                f'url={_url_preview(url)}'
            )
        return ok

    # googlevideo：小 Range 与 iOS MediaExtractor 对齐；整文件 GET 常 403。
    gv_range = _GOOGLEVIDEO_PROBE_RANGE if _is_googlevideo(url) else None

    if protocol in ('http_dash_segments', 'dash'):
        ok, reason = _probe_http(
            url,
            headers,
            range_header=gv_range,
            read_bytes=_PROBE_READ_BYTES,
            reject_text_body=bool(gv_range),
        )
    else:
        # 非 googlevideo progressive 不用 Range，避免「只拒 Range」的 CDN 误杀。
        ok, reason = _probe_http(
            url,
            headers,
            range_header=gv_range,
            read_bytes=_SEGMENT_READ_BYTES,
            reject_text_body=True,
        )

    if not ok:
        _log(
            f'remove format_id={format_id} kind=progressive '
            f'reason={reason} url={_url_preview(url)}'
        )
    return ok


def _probe_unique_urls(url_to_fmt, max_workers):
    """并发探测已按 URL 去重的 format mapping。

    Args:
        url_to_fmt: ``URL -> 首次出现 format`` 的 mapping。
        max_workers: 线程池上限；有任务时必须为正值。

    Returns:
        明确探测失败的 URL 集合。

    Raises:
        ValueError: 有任务且 worker 上限无效时由线程池抛出。

    Side Effects:
        创建短生命周期线程池并并发联网。worker 未预期异常会被记录后 soft-keep；
        日志缓冲区无锁，顺序不保证。googlevideo URL 单独限并发，降低群刷 403。
    """
    if not url_to_fmt:
        return set()

    gv_items = []
    other_items = []
    for item in url_to_fmt.items():
        if _is_googlevideo(item[0]):
            gv_items.append(item)
        else:
            other_items.append(item)

    bad_urls = set()

    def run_probe(item):
        """在线程 worker 中返回 URL 及其单项探测结果。"""
        probe_url, fmt = item
        return probe_url, probe_format(fmt)

    def _run_pool(items, workers_cap):
        if not items:
            return
        workers = max(1, min(workers_cap, len(items)))
        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = [executor.submit(run_probe, item) for item in items]
            for future in as_completed(futures):
                try:
                    probe_url, ok = future.result()
                    if not ok:
                        bad_urls.add(probe_url)
                except Exception as exc:  # noqa: BLE001
                    _log(f'probe exception keep url err={exc}')
                    continue

    if gv_items:
        _log(
            f'googlevideo probe urls={len(gv_items)} '
            f'workers={min(_GOOGLEVIDEO_MAX_WORKERS, len(gv_items))}'
        )
        _run_pool(gv_items, _GOOGLEVIDEO_MAX_WORKERS)
    if other_items:
        _run_pool(other_items, max_workers)
    return bad_urls


def filter_unreachable_formats(formats, max_workers=_DEFAULT_MAX_WORKERS):
    """按 URL 去重并发探测 format 列表。

    Args:
        formats: yt-dlp format 列表或空值。
        max_workers: 最大并发线程数。

    Returns:
        ``(kept_formats, removed_count)``；保持输入相对顺序，并额外移除 storyboard。
        空输入原样返回并附零计数。若探测后无法组成可下载集合（例如音轨全被
        群刷 403 误杀），而探测前可组成，则 soft-keep 探测前列表，避免只剩无声轨。

    Raises:
        输入元素非 mapping、worker 参数无效等准备阶段异常可能传播。

    Side Effects:
        对每个唯一 HTTP(S) URL 最多探测一次；重复 URL 沿用首次 format 的 headers，
        结果应用到所有重复项。会真实联网和写日志，不修改原列表。
    """
    if not formats:
        return formats, 0

    pre_probe = strip_storyboard_formats(formats)
    url_to_fmt = {}
    skipped = 0
    for fmt in formats:
        if _should_skip_probe(fmt):
            skipped += 1
            continue
        url = fmt.get('url')
        if not url or not url.startswith(('http://', 'https://')):
            continue
        url_to_fmt.setdefault(url, fmt)

    _log(
        f'begin formats={len(formats)} unique_probe_urls={len(url_to_fmt)} '
        f'skipped_non_probe={skipped}'
    )
    bad_urls = _probe_unique_urls(url_to_fmt, max_workers)
    stripped = strip_storyboard_formats(
        [fmt for fmt in formats if fmt.get('url') not in bad_urls]
    )
    removed = len(formats) - len(stripped)

    # 群刷/瞬时 403 误杀后只剩纯视频 → 写回任务缺音频；回退到探测前可用集合。
    if (
        removed > 0
        and not _is_usable_download_set(stripped)
        and _is_usable_download_set(pre_probe)
    ):
        _log(
            f'soft-keep pre-probe formats kept_after_probe={len(stripped)} '
            f'removed={removed} reason=unusable_av_set_after_probe'
        )
        return pre_probe, 0

    _log(
        f'done kept={len(stripped)} removed={removed} '
        f'bad_urls={len(bad_urls)}'
    )
    return stripped, removed


def filter_unreachable_urls(urls, headers=None, max_workers=_DEFAULT_MAX_WORKERS):
    """去重并有限探测推荐直链。

    Args:
        urls: 推荐 URL iterable。
        headers: 所有构造 format 共用的 info 级请求头。
        max_workers: 最大并发线程数。

    Returns:
        保持首次出现顺序的 URL 列表；重复项删除，明确失败项过滤。非 HTTP(S) URL
        不探测但会保留。

    Raises:
        URL 类型不支持字符串操作、worker 参数无效等异常可能传播。

    Side Effects:
        对唯一 HTTP(S) URL 并发执行真实有限 GET 并写日志。
    """
    unique_urls = []
    seen = set()
    for url in urls or []:
        if not url or url in seen:
            continue
        seen.add(url)
        unique_urls.append(url)

    if not unique_urls:
        return []

    url_to_fmt = {}
    for url in unique_urls:
        if not url.startswith(('http://', 'https://')):
            continue
        protocol = 'm3u8' if _looks_like_m3u8(url) else 'https'
        fmt = {'url': url, 'protocol': protocol, 'http_headers': headers or {}}
        if _should_skip_probe(fmt):
            continue
        url_to_fmt[url] = fmt

    _log(f'filter_urls begin count={len(url_to_fmt)}')
    bad_urls = _probe_unique_urls(url_to_fmt, max_workers)
    kept = [url for url in unique_urls if url not in bad_urls]
    _log(f'filter_urls done kept={len(kept)} removed={len(bad_urls)}')
    return kept
